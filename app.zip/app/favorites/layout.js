export default function FavoritesLayout({ children }) {
    return (
      <div>
        <h1>Favorites</h1>
        {children}
      </div>
    );
  }
  