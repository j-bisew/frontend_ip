export default function HomePage() {
  return (
    <div>
      <h1>Welcome to the Pokémon App!</h1>
      <p>Explore and discover information about your favorite Pokémon.</p>
    </div>
  );
}