export default function PokemonDetailLayout({ children }) {
    return (
      <div>
        <h2>Pokémon Details</h2>
        {children}
      </div>
    );
  }